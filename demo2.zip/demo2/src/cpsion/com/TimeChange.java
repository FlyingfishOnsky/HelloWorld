package cpsion.com;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

public class TimeChange {
	public static void main(String[] args) {
		//获取当前日期
//		Date today=new Date();
//		System.out.println("当前日期======="+today);
//		Calendar instance = Calendar.getInstance();
//		instance.add(instance.DATE,-1);
//		System.out.println("当前日期======="+instance);
//		
		SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd");
//		String format = simpleDateFormat.format(instance.getTime());
//		String start_time=format+" 00:00:00";
//		String end_time=format+" 23:59:59";
//		System.out.println(start_time);
//		System.out.println(end_time);
		String s="2018-05-01";
	
		try {
			Calendar instance = Calendar.getInstance();
			Date parse = simpleDateFormat.parse(s);
			instance.setTime(parse);
			instance.add(instance.DATE, -1);
			System.out.println(instance.getTime());
			System.out.println(simpleDateFormat.format(instance.getTime()));
		} catch (ParseException e) {
			e.printStackTrace();
		}
		
		
		
		
		
		
	}
}
