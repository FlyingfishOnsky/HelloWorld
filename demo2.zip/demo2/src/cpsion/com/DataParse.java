package cpsion.com;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class DataParse {
	
	public static void main(String[] args) throws Exception {
		String date="2015-08-02";
		SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd");
		Date parse = simpleDateFormat.parse(date);
		System.out.println(parse);
		 SimpleDateFormat sdf = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
		 String format = sdf.format(parse);
		 System.out.println(format);
		 System.out.println(simpleDateFormat.parse(format));
	}
	

}
